// Get elements from the DOM
const selectedImage = document.getElementById('selected-image');
const imageInput = document.getElementById('image-input');
const imageFormatSelect = document.getElementById('image-format');
const imageResizeInput = document.getElementById('image-resize');
const processButton = document.getElementById('process-button');
const downloadButton = document.getElementById('download-button');
const progressBar = document.getElementById('progress-bar');
const progressBarFill = document.getElementById('progress-bar-fill');
const processedImage = document.getElementById('processed-image');

// Define image processing function
async function processImage() {
  // Get the selected image and its file type
  const image = selectedImage.src;
  const fileType = image.slice(11, image.indexOf(';'));

  // Get the image format and resize percentage
  const imageFormat = imageFormatSelect.value;
  const resizePercentage = imageResizeInput.value / 100;

  // Disable the process button and show the progress bar
  processButton.disabled = true;
  processButton.classList.add('opacity-50', 'cursor-default');
  progressBar.classList.remove('hidden');

  // Create a canvas element to resize the image
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');

  // Create a new image element to store the resized image
  const resizedImage = new Image();

  // Wait for the image to load before resizing it
  resizedImage.onload = function() {
    // Set the canvas dimensions to match the resized image
    canvas.width = resizedImage.width;
    canvas.height = resizedImage.height;

    // Draw the resized image onto the canvas
    context.drawImage(resizedImage, 0, 0, resizedImage.width, resizedImage.height);

    // Convert the canvas image to a data URL with the desired format
    const processedImageURL = canvas.toDataURL(`image/${imageFormat}`);

    // Set the processed image source and show it
    processedImage.src = processedImageURL;
    processedImage.classList.remove('hidden');

    // Enable the download button with the processed image data
    downloadButton.href = processedImageURL;
    downloadButton.classList.remove('hidden');

    // Hide the progress bar and enable the process button
    progressBar.classList.add('hidden');
    processButton.disabled = false;
    processButton.classList.remove('opacity-50', 'cursor-default');
  };

  // Load the selected image and set the source of the resized image
  resizedImage.src = selectedImage.src;

  // Resize the image to the desired percentage
  resizedImage.width *= resizePercentage;
  resizedImage.height *= resizePercentage;
}

// Add event listener to image input
imageInput.addEventListener('change', function() {
  // Get the selected image file and create a URL for it
  const file = this.files[0];
  const url = URL.createObjectURL(file);

  // Set the source of the selected image and show it
  selectedImage.src = url;
  selectedImage.classList.remove('hidden');
});

// Add event listener to process button
processButton.addEventListener('click', processImage);
